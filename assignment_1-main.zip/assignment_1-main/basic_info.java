class basic_info{
    public static void main(String args[]){
	    System.out.println("My name is Drishti Pala, Recently Appeared for TY Final examination from Shankar Narayan College");
	}
}